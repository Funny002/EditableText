import { EditorFactory } from './abstract';

/**
 * Editor
 */
export class Editor extends EditorFactory {}
