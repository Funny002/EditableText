import { WithEditorFirst } from '../types';
import { Editor } from '../interface';

export const apply: WithEditorFirst<Editor['apply']> = (editor, op) => {
  console.log(editor, op);
};
