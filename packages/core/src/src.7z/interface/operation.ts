import { ExtendedType } from '../types';

interface BaseOperation {

}

export type Operation = ExtendedType<'Operation', BaseOperation>
