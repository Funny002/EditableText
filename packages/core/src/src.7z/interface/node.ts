import { ExtendedType } from '../types';

export interface BaseElement {
  children: Descendant[];
}

export type Element = ExtendedType<'Element', BaseElement>

export interface BaseText {
  text: string;
}

export type Text = ExtendedType<'Text', BaseText>

export type Descendant = Element | Text;
